﻿using TestWebshop.Models.Database;

namespace TestWebshop.Models.ViewModels
{
    public class CarouselMostPopularVM
    {

        public Movie Movie { get; set; }

        public int Quantity { get; set; }


    }
}
